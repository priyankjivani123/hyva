<?php
namespace Priyank\HidePrice\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\View\LayoutInterface;

class Data extends AbstractHelper
{
    protected $layout;

    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        LayoutInterface $layout
    ) {
        parent::__construct($context);
        $this->layout = $layout;
    }

     public function isEnabled(): bool
    {
        return $this->scopeConfig->isSetFlag('hideprice/settings/enabled', ScopeInterface::SCOPE_STORE);
    }
    /**
     * Check whether price should be shown based on context
     */
    public function canShowPrice(string $context = ''): bool
    {
        switch ($context) {
            case 'hide_for_product_page':
                return !$this->scopeConfig->isSetFlag('hideprice/settings/hide_for_product_page', ScopeInterface::SCOPE_STORE);
            case 'hide_for_all_product':
                return !$this->scopeConfig->isSetFlag('hideprice/settings/hide_for_all_product', ScopeInterface::SCOPE_STORE);
            default:
                return false;
        }
    }

}
