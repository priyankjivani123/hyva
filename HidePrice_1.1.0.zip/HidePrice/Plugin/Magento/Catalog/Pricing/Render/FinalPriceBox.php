<?php
/**
 * Copyright © Priyank Jivani All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Priyank\HidePrice\Plugin\Magento\Catalog\Pricing\Render;

use Priyank\HidePrice\Helper\Data;

class FinalPriceBox
{
    /**
     * @var Data
     */
    protected $helper;

    /**
     * Constructor
     */
    public function __construct(
        Data $helper
    ) {
        $this->helper = $helper;
    }

    /**
     * Plugin to hide final price
     */
    public function aroundToHtml(
        \Magento\Catalog\Pricing\Render\FinalPriceBox $subject,
        \Closure $proceed
    ) {
        $result = $proceed();

        if (!$this->helper->canShowPrice('hide_for_all_product') && $this->helper->isEnabled()) {
            return '';
        }

        return $result;
    }
}
