<?php
/**
 * Copyright © Priyank Jivani All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Priyank\HidePrice\Plugin\Magento\Catalog\Block\Product;

use Priyank\HidePrice\Helper\Data;


class Price
{
	 /**
     * @var Data
     */
    protected $helper;

    /**
     * Constructor
     */
    public function __construct(
        Data $helper
    ) {
        $this->helper = $helper;
    }

    /**
     * Plugin to hide final price
     */
    public function afterToHtml(
        \Magento\Catalog\Block\Product\Price $subject,
        $result
    ) {
		if (!$this->helper->canShowPrice('hide_for_product_page') && $this->helper->isEnabled()) {
            return '';
        }
        return $result;
    }
}
