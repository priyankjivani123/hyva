<?php
\Magento\Framework\Component\ComponentRegistrar::register(\Magento\Framework\Component\ComponentRegistrar::THEME, 
    'frontend/Hyva/child', 
    __DIR__
);