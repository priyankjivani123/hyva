<?php
namespace Priyank\HidePrice\ViewModel;

use Magento\Framework\View\Element\Block\ArgumentInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\View\LayoutInterface;

class HidePrice implements ArgumentInterface
{
    protected $scopeConfig;
    protected $layout;

    public function __construct(
        ScopeConfigInterface $scopeConfig,
        LayoutInterface $layout
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->layout = $layout;
    }

    public function canShowPrice(string $context = ''): bool
    {
        $handles = $this->layout->getUpdate()->getHandles();

        switch ($context) {
            case 'related':
                return !$this->scopeConfig->isSetFlag('hideprice/settings/related');
            case 'upsell':
                return !$this->scopeConfig->isSetFlag('hideprice/settings/upsell');
            case 'crosssell':
                return !$this->scopeConfig->isSetFlag('hideprice/settings/crosssell');
            case 'product':
                return !$this->scopeConfig->isSetFlag('hideprice/settings/product');
            case 'category':
                return !$this->scopeConfig->isSetFlag('hideprice/settings/category');
            case 'search':
                return !$this->scopeConfig->isSetFlag('hideprice/settings/search');
            default:
                return true;
        }
    }
}
